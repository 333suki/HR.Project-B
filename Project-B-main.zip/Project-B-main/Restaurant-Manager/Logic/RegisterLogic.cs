﻿static class RegisterLogic {

}
