﻿// This class stores "global" variables
public static class State {
    public static User? LoggedInUser = null;
}
