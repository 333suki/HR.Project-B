﻿public static class MenuLogic
{

}