<img src="eepy.jpg" alt="Eepy cat" width="100%" height="250"/>

# Project B by Team eepy 😸

## Authors

- [@Zjoswaa](https://github.com/Zjoswaa)
- [@333suki](https://github.com/333suki)
- [@TomvGenderen](https://github.com/TomvGenderen)
- [@humbertotan0182](https://github.com/humbertotan0182)

## Project Board
[GitHub Project Board](https://github.com/users/333suki/projects/2)
